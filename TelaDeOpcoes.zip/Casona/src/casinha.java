import java.util.Scanner;
import java.util.Random;
public class casinha {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int vetor[] = new int[10];

		System.out.println("MENU DE OPÇÕES");

		System.out.println("1 opção: Coleta dados do vetor");

		System.out.println("2 opção: Gera valores randômicos para o vetor");

		System.out.println("3 opção: Imprime dados do vetor");

		System.out.println("4 opção: Imprime vetor invertido");

		System.out.println("5 opção: Soma valores do vetor");

		System.out.println("6 opção: Soma personalizada de valores do vetor");

		System.out.println("7 opção: Média dos valores do vetor");

		System.out.println("8 opção: Maior valor dentro do vetor");

		System.out.println("9 opção: Menor valor dentro do vetor");

		System.out.println("10 opção: Ordenação do vetor por Bubble");

		System.out.println("11 opção: Ordenação do vetor por Insertion");

		System.out.println("12 opção: Ordenação do vetor por Selection");

		System.out.println("13 opção: Busca sequencial");

		System.out.println("14 opção: Busca binária");

		System.out.println("digite 0 para sair");

		System.out.println("Digite a opção desejada:");

		int opcao = teclado.nextInt();

		while(opcao != 0) {

		if(opcao == 1) {

		int chamada1[] = coletaVetor(vetor);

		for( int i = 0; i < vetor.length; i++) {

		System.out.println(chamada1[i]);

		}
		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();

		}


		if(opcao == 2) {

		System.out.println("Informe um valor máximo");
		int max = teclado.nextInt();
		int chamada2[] = geraVetorRandomico(vetor, max);
		for(int i2 = 0; i2 < vetor.length; i2++) {
		System.out.println(chamada2[i2]);
		}
		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao == 3) {

		imprimeVetor(vetor);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao == 4) {

		imprimeVetorInvertido(vetor);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao == 5) {

		int chamada5 = somaTodos(vetor);
		System.out.println(chamada5);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao == 6) {
		System.out.println("Informe o inicio do intervalo");
		int inicio = teclado.nextInt();

		System.out.println("Informe o final do intervalo");
		int termino = teclado.nextInt();

		if(inicio < 0) {
		System.out.println("Verifique as restrições do algoritmo");
		}
		if(termino > vetor.length) {
		System.out.println("Verifique as restrições do algoritmo");
		}
		if(inicio > termino) {
		System.out.println("O intervalo foi informado incorretamente");
		}
		else {
		int chamada6 = somaPersonalizada(vetor, inicio, termino);
		System.out.println(chamada6);
		}

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao == 7) {

		double chamada7 = media(vetor);
		System.out.println(chamada7);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao == 8) {

		int chamada8 = maiorValor(vetor);
		System.out.println(chamada8);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao == 9) {

		int chamada9 = menorValor(vetor);
		System.out.println(chamada9);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}


		if(opcao ==10) {
		Bolha(vetor);
		for(int i = 0; i < vetor.length; i++) {
		System.out.println("Valor: " + vetor[i]);
		}

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}

		if(opcao == 11) {
		Insert(vetor);
		for(int i = 0; i < vetor.length; i++) {
		System.out.println("Valor: " + vetor[i]);
		}

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}

		if(opcao == 12) {
		   Select(vetor);
		   for(int i = 0; i < vetor.length; i++) {
		System.out.println("Valor: " + vetor[i]);
		}
		   
		   System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}

		if(opcao == 13) {
		System.out.println("Informe o valor que deseja encontrar:");
		int valor = teclado.nextInt();

		Sequencial(vetor, valor);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}

		if(opcao == 14) {
		System.out.println("Informe o valor que deseja encontrar:");
		        int valor = teclado.nextInt();
		        
		Binário(vetor, valor);

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();

		}

		if(opcao < 0) {
		System.out.println("opção inválida");

		System.out.println("Digite a opção desejada:");
		opcao = teclado.nextInt();
		}

		if(opcao == 0) {
		System.out.println("Fim do algoritmo");
		}
		}
		}

		public static int[] coletaVetor(int []vetor) {

		Scanner teclado = new Scanner(System.in);

		int valor = 1;

		while (valor < 10) {

		for(int i = 0; i < vetor.length; i++) {

		System.out.println("Informe o " + valor + " valor do vetor:");

		vetor[i] = teclado.nextInt();

		valor++;

		}

		}

		return vetor;

		}


		public static int[] geraVetorRandomico(int[] vetor, int max){

		Random ale = new Random();

		for(int i = 0; i < vetor.length; i++) {

		vetor[i] = ale.nextInt(max);
		     
		}

		return vetor;

		}


		public static void imprimeVetor(int[] vetor) {
		for(int i = 0; i < vetor.length; i++) {

		System.out.println(vetor[i]);
		}

		}


		public static void imprimeVetorInvertido(int[] vetor) {

		for(int i = vetor.length - 1; i >= 0; i--) {

		System.out.println(vetor[i]);
		}
		}


		public static int somaTodos(int[] vetor) {

		int soma = 0;

		for(int i = 0; i < vetor.length; i++) {
		soma += vetor[i];
		}
		return soma;
		}


		public static int somaPersonalizada(int[] vetor, int inicio, int termino) {

		int soma = 0;
		for(int i = inicio; i < termino; i++) {

		soma+= vetor[i];

		}
		return soma;
		}


		public static double media(int[] vetor) {

		double media = 0;
		double soma = 0;
		for(int i = 0; i < vetor.length ; i++) {
		soma+= vetor[i];
		media = soma / vetor.length ;
		}
		return media;
		}


		public static int maiorValor(int[] vetor) {

		int valor = vetor[0];
		for(int i = 0; i < vetor.length ; i++) {
		if(valor < vetor[i]) {
		valor = vetor[i];
		}
		}
		return valor;
		}


		public static int menorValor(int[] vetor) {

		int valor = vetor[0];
		for(int i = 0; i < vetor.length ; i++) {
		if(valor > vetor[i]) {
		valor = vetor[i];
		}
		}
		return valor;
		}


		public static void Bolha(int[] vetor) {
		for(int cont = 1; cont < vetor.length; cont++) {
		for(int i = 0; i < vetor.length-1; i++) {
		if(vetor[i] > vetor[i+1]) {
		int temp = vetor[i];
		vetor[i] = vetor[i+1];
		vetor[i+1] = temp;
		}
		}
		}

		}


		public static void Insert(int[] vetor) {

		for(int i = 1; i < vetor.length; i++) {
		int valor = vetor[i];
		int iAnterior = i-1;
		while( iAnterior >= 0 && vetor[iAnterior] > valor ) {
		vetor[iAnterior + 1] = vetor[iAnterior];
		iAnterior = iAnterior -1;
		}
		vetor[iAnterior + 1] = valor;
		}
		}

		public static void Select(int[] vetor) {

		for(int i = 0; i < vetor.length-1; i++) {
		int indice = i;
		for(int j = i+1; j < vetor.length; j++) {
		if(vetor[j] < vetor[indice]) {
		indice = j;
		}
		}
		int menorValor = vetor[indice];
		vetor[indice] = vetor[i];
		vetor[i] = menorValor;
		}
		}

		public static void Sequencial(int[] vetor, int valor) {

		Boolean achou = false;
		for(int i = 0; i < vetor.length; i++) {
		if(vetor[i] == valor) {
		achou = true;
		System.out.println(" O valor " + valor + " está no índice " + i);
		break;
		}

		}
		if(achou == false) {
		System.out.println("O valor não está presente no vetor");
		}
		}

		public static void Binário(int[] vetor, int valor) {

		int inicio = 0;
		int fim = vetor.length - 1;
		int meio;
		int indice = 0;
		while(inicio <= fim) {
			 meio = (inicio + fim) / 2;
			if( vetor[meio] == valor) {
				indice = meio;
				break;
			}
			
			else {
				if(vetor[meio] > valor) {
				fim = meio - 1; 
			}
			
			else {
				inicio = meio + 1;
			}
			}
			
			
		}
		if(indice != valor) {
			System.out.println("O valor não se encontra no vetor");
		}else {
		System.out.println("O valor " + valor + " está no índice " + indice);
		}
		
		
	/*	 if(vetor[meio] > valor) {
		fim = meio - 1;
		for(int i = inicio; i < fim; i++) {
		if(vetor[i] == valor) {
		System.out.println("O valor " + valor + " está no índice " + i);
		}
		}

		}else if(vetor[meio] < valor) {
		inicio = meio + 1;
		for(int i = inicio; i < fim; i++) {
		if(vetor[i] == valor) {
		System.out.println("O valor " + valor + " está no índice " + i);
		}
		}
		}

		else if(vetor[meio] == valor) {
				System.out.println("O valor " + valor + " está no índice " + meio);
			
			}
			*/
		}
		}
