
import java.util.Scanner;

public class teste2 {
	public static boolean Primos(int num) {

		if (num <= 1)

			return false; // 0 e 1 não são primos

		for (int cont = 2; cont <= Math.sqrt(num); cont++) {

			if (num % cont == 0) {

				return false;

			}

		}

		return true;

	}

	public static int[] gerarPrimos(int quantidade) {

		int[] primos = new int[quantidade];

		int num = 2; // Primeiro número primo

		int count = 0;

		while (count < quantidade) {

			if (Primos(num)) {

				primos[count] = num;

				count++;

			}

			num++;

		}

		return primos;

	}

	private static int getCodigoDaLetra(char letra) {

		char[] alfabeto = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

		int[] primos = gerarPrimos(alfabeto.length);// o tamanho do vetor de primos é

		// Encontra o índice da letra no array alfabeto

		for (int i = 0; i < alfabeto.length; i++) {

			if (alfabeto[i] == letra) {

				return primos[i];

			}

		}

		return 1; // Retorna 1 se a letra não estiver no alfabeto no caso dos espaços

	}

	public static void gerarMatrizChave() {
		int linhas = 2;
		int colunas = 2; // Definindo o número de colunas

		int matrizChave[][] = new int[linhas][colunas];

		// Definindo os valores da matriz chave
		matrizChave[0][0] = 4;
		matrizChave[0][1] = 5;
		matrizChave[1][0] = 3;
		matrizChave[1][1] = 4;

		for (int lin = 0; lin < linhas; lin++) {
			for (int col = 0; col < colunas; col++) {
				System.out.print(matrizChave[lin][col] + " ");
			}
			System.out.println();
		}
	}

	public static int[][] multiplicarMatrizes(int[][] matrizA, int[][] matrizB) {
		int linhasA = matrizA.length;
		int colunasA = matrizA[0].length;
		int linhasB = matrizB.length;
		int colunasB = matrizB[0].length;

		if (colunasA != linhasB) {
			System.out.println("Número de colunas da matriz A deve ser igual ao número de linhas da matriz B.");
		}

		int[][] resultado = new int[linhasA][colunasB];

		for (int i = 0; i < linhasA; i++) {
			for (int j = 0; j < colunasB; j++) {
				resultado[i][j] = 0;
				for (int k = 0; k < colunasA; k++) {
					resultado[i][j] += matrizA[i][k] * matrizB[k][j];
				}
			}
		}

		return resultado;
	}

	public static int calcularDeterminante(int[][] matriz) {
		if (matriz.length == 2 && matriz[0].length == 2) {
			int a = matriz[0][0];
			int b = matriz[0][1];
			int c = matriz[1][0];
			int d = matriz[1][1];
			return (a * d) - (b * c);
		} else if (matriz.length == 1 && matriz[0].length == 1) {
			return matriz[0][0];
		} else {
			System.out.println("O cálculo do determinante só é possível para matrizes 2x2 ou 1x1");
			return 0;
		}
	}

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
	    int[][] matrizChave = { { 4, 5 }, { 3, 4 } };
	    System.out.println("Matriz Chave:");
	    gerarMatrizChave();

	    System.out.println("Informe uma frase");

	    String mensagem = teclado.nextLine();

	    int linhas;
	    int colunas;

	    // Transforma a mensagem para maiúsculo
	    mensagem = mensagem.toUpperCase();

	    // Verifica se a mensagem contém apenas um caractere
	    if (mensagem.length() == 1) {
	        linhas = 1;
	        colunas = 1;
	    } else {
	        linhas = 2;
	        colunas = mensagem.length() / 2;
	        // Ajusta o número de colunas se a frase tiver número ímpar de caracteres
	        colunas = mensagem.length() % 2 == 0 ? colunas : colunas + 1;
	    }

	    int matrizB[][] = new int[linhas][colunas];
	    char matrizC[][] = new char[linhas][colunas];

	    int cont = 0;

	    // Percorre a mensagem e transforma para matriz
	    for (int lin = 0; lin < linhas; lin++) {
	        for (int col = 0; col < colunas; col++) {
	            if (cont < mensagem.length()) {
	                char letra = mensagem.charAt(cont);
	                matrizC[lin][col] = letra;
	                matrizB[lin][col] = getCodigoDaLetra(letra);
	            }
	            cont++;
	        }
	    }

	    // Imprime a matriz de letras
	    for (int lin = 0; lin < linhas; lin++) {
	        for (int col = 0; col < colunas; col++) {
	            System.out.print(matrizC[lin][col] + " ");
	        }
	        System.out.println();
	    }

	    // Imprime a matriz de números primos
	    System.out.println();
	    for (int lin = 0; lin < linhas; lin++) {
	        for (int col = 0; col < colunas; col++) {
	            System.out.print(matrizB[lin][col] + " ");
	        }
	        System.out.println();
	    }

	    // Verifica se a matriz é quadrada e pode ter seu determinante calculado
	    if ((linhas == 1 && colunas == 1) || (linhas == 2 && colunas == 2)) {
	        int determinante = calcularDeterminante(matrizB);
	        System.out.println("Determinante da matriz principal: " + determinante);
	        System.out.println();
	    } else {
	        System.out.println("Não é possível calcular o determinante da matriz pois ela não é quadrada.");
	        System.out.println();
	    }

	    // Verifica se a multiplicação das matrizes é possível
	    if (matrizChave[0].length == matrizB.length) {
	        int[][] matrizResultado = multiplicarMatrizes(matrizChave, matrizB);

	        // Imprime o resultado da multiplicação
	        System.out.println("Resultado da Multiplicação:");
	        for (int lin = 0; lin < matrizResultado.length; lin++) {
	            for (int col = 0; col < matrizResultado[0].length; col++) {
	                System.out.print(matrizResultado[lin][col] + " ");
	            }
	            System.out.println();
	        }
	    } else {
	        System.out.println("Não é possível multiplicar as matrizes. Dimensões incompatíveis.");
	    }

	}
}
