/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gustavo.ingrid.vitoria.biblioteca.operacoesUsuario;


import gustavo.ingrid.vitoria.biblioteca.conexao.Conexao;
import java.sql.PreparedStatement;
import gustavo.ingrid.vitoria.biblioteca.usuário.Usuário;
/**
 *
 * @author Aluno
 */
public class OperacoesUsuario {
    
      public static void inserir(Usuário usuario) {
        String sql = "INSERT INTO Usuário (email, senha) VALUES (?, ?)";

        try {
            PreparedStatement sqlPreparada = Conexao.getConexao().prepareStatement(sql);
            sqlPreparada.setString(1, usuario.getEmail());
            sqlPreparada.setString(2, usuario.getSenha());
            sqlPreparada.executeUpdate();
            System.out.println("gustavo.ingrid.vitoria.biblioteca.operacoesUsuario.OperacoesUsuario.inserir()");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
