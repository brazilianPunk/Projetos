package gustavo.ingrid.vitoria.biblioteca;

public class Biblioteca {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
