package la;

import java.util.Scanner;

public class La {

	public static void main(String[] args) {
		        Scanner input = new Scanner(System.in);

		        // Entrada dos pontos A e B (um valor por vez)
		        System.out.print("Digite o valor de x1 (ponto A): ");
		        double x1 = input.nextDouble();

		        System.out.print("Digite o valor de y1 (ponto A): ");
		        double y1 = input.nextDouble();

		        System.out.print("Digite o valor de x2 (ponto B): ");
		        double x2 = input.nextDouble();

		        System.out.print("Digite o valor de y2 (ponto B): ");
		        double y2 = input.nextDouble();
		        //Matriz do determinante 3x3
		        // | x1  y1  1 |x1 y1
		        // | x2  y2  1 |x2 y2
		        // | x   y   1 |x  y
		        //para calcular o determinate que vai ser a reta primeiro multiplicamos
		        //1°x1*y2*1 
		        //y1*1*x3 
		        //1*x2*1 
		        //depois vamos para parte que multiplicamos e tem que ficar o 
		        //resultado oposto se der na multiplicação por exemplo x fica -x
		        // então o x*y2*1
		        //y*1*x1
		        //1*x2*y1..tepois ao fim somamos todos os resultados dessas 6 multiplicações 

		        // Ponto fictício P (x, y)
		        double x = 1.0;
		        double y = 1.0;

		        // Determinante 3x3
		        double parte1 = x1 * y2 * 1 + y1 * 1 * x + 1 * x2 * y;
		        double parte2 = x * y2 * 1 + y * 1 * x1 + 1 * x2 * y1;
		        double determinante = parte1 - parte2;

		        System.out.println("\nDeterminante = " + determinante);

		        // Equação geral da reta: Ax + By + C = 0
		        double A = y1 - y2;
		        double B = x2 - x1;
		        double C = x1 * y2 - x2 * y1;

		        System.out.printf("\nEquação geral da reta: %.2fx + %.2fy + %.2f = 0\n", A, B, C);

		        // Forma reduzida: y = mx + b
		        if (x2 - x1 != 0) {
		            double m = (y2 - y1) / (x2 - x1);
		            double b = y1 - m * x1;
		            System.out.printf("Forma reduzida da reta: y = %.2fx + %.2f\n", m, b);
		        } else {
		            System.out.println("A reta é vertical: x = " + x1);
		        }

		        input.close();
		    }
		}
