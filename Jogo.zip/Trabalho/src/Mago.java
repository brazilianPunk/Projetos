import java.util.Random;
public class Mago {

Random ale = new Random();

    String nome;
	double pontosV ;
	int pontosA;
	int pontosD;
	int inteligencia ;
	int recuperacao ;
	
	public static int pontosV() {
		Random ale = new Random();
		return 100;
	}
	
	public static int pontosA() {
		Random ale = new Random();
		return  ale.nextInt(6) + 20;
	}
	
	public static int pontosD() {
		Random ale = new Random();
		return  ale.nextInt(6) + 5;
	}
	
	public static int inteligencia() {
		Random ale = new Random();
		return ale.nextInt(9) + 2 ;
	}
	
	public static int recuperacao() {
		Random ale = new Random();
		return (ale.nextInt(9) + 2) ;
	}
}

