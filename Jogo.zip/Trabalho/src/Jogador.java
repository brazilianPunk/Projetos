import java.util.Scanner;
public class Jogador {

	Scanner teclado = new Scanner(System.in);
	
	String nome ;
	
	
}
