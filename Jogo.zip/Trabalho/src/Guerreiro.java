import java.util.Random;
public class Guerreiro {

	Random ale = new Random();
	
	String nome;
	double pontosV;
	int pontosA ;
	int pontosD ;
	int força;
	int velocidade;
	
	public static int pontosV() {
		return 100;
	}
	
	public static int pontosA() {
		Random ale = new Random();
		return ale.nextInt(6) + 15;
	}
	
	public static int pontosD() {
		Random ale = new Random();
		return ale.nextInt(6) + 10;
	}
	
	public static int forca() {
		Random ale = new Random();
		return (ale.nextInt(9) + 2) ;
	}
	
	public static int velocidade() {
		Random ale = new Random();
		return (ale.nextInt(9) + 2);
	}
}
 