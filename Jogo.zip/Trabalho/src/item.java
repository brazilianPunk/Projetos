import java.util.Random;

public class item {
	String descricao;
	char tipoPersonagem;
	char modalidade;
	int precoItem;
	int bonusDefesa;
	int bonusAtaque;
	public static int calcularPreco() {
		return 10;
	}
	public static int calcularBonusDefesa() {
		Random ale = new Random();
		return ale.nextInt(8) + 2;	
	}
	public static int calcularBonusAtaque() { 
		Random ale = new Random();
		return ale.nextInt(8) + 2;
		}
}

