import java.util.Scanner;
import java.util.Random;

public class Batalha {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        Jogador j1 = new Jogador();
        Jogador j2 = new Jogador();

        Guerreiro G = new Guerreiro();
        Mago M = new Mago();

        System.out.println("Digite o nome do jogador 1:");
        j1.nome = teclado.nextLine();

        System.out.println("Jogador 1: " + j1.nome);
        System.out.println("");

        System.out.println("Digite o nome do jogador 2:");
        j2.nome = teclado.nextLine();

        System.out.println("Jogador 2: " + j2.nome);
        System.out.println("");

        System.out.println(j1.nome + ", Escolha um personagem");
        System.out.println(" 1: Guerreiro");
        System.out.println(" 2: Mago");

        int tipoPersonagem1 = teclado.nextInt();

        while (tipoPersonagem1 != 1 && tipoPersonagem1 != 2) {
            System.out.println("Opção inválida");
            System.out.println(j1.nome + ", Escolha um personagem");
            System.out.println("1: Guerreiro");
            System.out.println("2: Mago");

            tipoPersonagem1 = teclado.nextInt();
        }

        if (tipoPersonagem1 == 1) {
            G = obterGuerreiro();
            listarGuerreiro(G);
            
            System.out.println(j2.nome + ", Você será o mago");
                     M = obterMago();
        } else if (tipoPersonagem1 == 2) {
            M = obterMago();
            listarMago(M);
            System.out.println(j2.nome + ", Você será o Guerreiro");
         
           G = obterGuerreiro();
        }

  
       
        
        boolean resultado = iniciarBatalha(tipoPersonagem1,G, M);
        verificarVencedor(G, M, resultado);
    }

    public static void gerenciarItem(char tipoP, Guerreiro g, Mago m) {
    	 Scanner teclado = new Scanner(System.in);

    	    item i = new item();

    	    System.out.println("Descrição do item:");
    	    i.descricao = teclado.nextLine();

    	    i.precoItem = 10;

    	    if (tipoP == 'G') {
    	        i.tipoPersonagem = 'G';
    	        g.pontosV -= i.precoItem;
    	    } else if (tipoP == 'M') {
    	        i.tipoPersonagem = 'M';
    	        m.pontosV -= i.precoItem;
    	    }

    	    System.out.println("Qual a modalidade do item? (A) ataque (D) defesa");
    	    char Decisao = teclado.next().charAt(0);
    	    while(Decisao != 'A' && Decisao != 'D') {
	        	System.out.println("Alternativa inválida");

	    	    System.out.println("Qual a modalidade do item? (A) ataque (D) defesa");
	    	     Decisao = teclado.next().charAt(0);
	        }
    	    if (Decisao == 'D' && tipoP == 'G') {
    	        i.modalidade = 'D';
    	        i.bonusDefesa = i.calcularBonusDefesa();
    	        g.pontosD += i.bonusDefesa;
    	    } else if (Decisao == 'A' && tipoP == 'G') {
    	        i.modalidade = 'A';
    	        i.bonusAtaque = i.calcularBonusAtaque();
    	        g.pontosA += i.bonusAtaque;
    	    } else if (Decisao == 'D' && tipoP == 'M') {
    	        i.modalidade = 'D';
    	        i.bonusDefesa = i.calcularBonusDefesa();
    	        m.pontosD += i.bonusDefesa;
    	    } else if (Decisao == 'A' && tipoP == 'M') {
    	        i.modalidade = 'A';
    	        i.bonusAtaque = i.calcularBonusAtaque();
    	        m.pontosA += i.bonusAtaque;
    	    } 

    	    System.out.println("Item aplicado com sucesso!");
    	}

    public static boolean roll() {
        Random ale = new Random();
        return ale.nextBoolean();
    }

    public static Guerreiro obterGuerreiro() {
        Scanner teclado = new Scanner(System.in);
        Guerreiro guerreiro = new Guerreiro();
        System.out.println("Digite o nome do guerreiro");
        guerreiro.nome = teclado.nextLine();
        guerreiro.pontosV = guerreiro.pontosV();
        guerreiro.pontosA = guerreiro.pontosA();
        guerreiro.pontosD = guerreiro.pontosD();
        guerreiro.força = guerreiro.forca();
        guerreiro.velocidade = guerreiro.velocidade();

         Conexao c = new Conexao("Jogo");
         String sql = "INSERT INTO jogo (nomeGuerreiro,pontosVGuerreiro,pontosAGuerreiro,pontosDGuerreiro,forca,velocidade) " +
                      "VALUES ('" + guerreiro.nome + "', " + guerreiro.pontosV + ", " + guerreiro.pontosA + ", " + guerreiro.pontosD + ", " + guerreiro.força + ", " + guerreiro.velocidade + ")";
         c.executarAtualizacao(sql);

        return guerreiro;
    }

    public static Mago obterMago() {
        Scanner teclado = new Scanner(System.in);
        Mago mago = new Mago();
         Conexao c = new Conexao("Jogo");
        System.out.println("Digite o nome do mago");
        mago.nome = teclado.nextLine();
        mago.pontosV = mago.pontosV();
        mago.pontosA = mago.pontosA();
        mago.pontosD = mago.pontosD();
        mago.inteligencia = mago.inteligencia();
        mago.recuperacao = mago.recuperacao();

         String sql = "INSERT INTO tabela_mistico (nomeMago, pontosVMago, pontosAMago, pontosDMado, inteligencia, recuperacao) " +
                      "VALUES ('" + mago.nome + "', " + mago.pontosV + ", " + mago.pontosA + ", " + mago.pontosD + ", " + mago.inteligencia + ", " + mago.recuperacao + ")";
         c.executarAtualizacao(sql);

        return mago;
    }

    public static void listarGuerreiro(Guerreiro guerreiro) {
        System.out.println("Nome: " + guerreiro.nome);
        System.out.println("Vida: " + guerreiro.pontosV);
        System.out.println("Ataque " + guerreiro.pontosA);
        System.out.println("Defesa " + guerreiro.pontosD);
        System.out.println("Força " + guerreiro.força);
        System.out.println("Velocidade " + guerreiro.velocidade);
        System.out.println("");
    }

    public static void listarMago(Mago mago) {
        System.out.println("Nome: " + mago.nome);
        System.out.println("Vida: " + mago.pontosV);
        System.out.println("Ataque " + mago.pontosA);
        System.out.println("Defesa " + mago.pontosD);
        System.out.println("Inteligencia " + mago.inteligencia);
        System.out.println("Recuperacao " + mago.recuperacao);
        System.out.println("");
    }

    public static void AplicarDano(Mago mago, Guerreiro guerreiro, boolean tipoP) {
        double dano;

        if (tipoP == true) {
        	guerreiro.pontosA = guerreiro.pontosA() * guerreiro.força;
        	mago.pontosD = mago.pontosD() * mago.recuperacao;
            dano = guerreiro.pontosA - mago.pontosD;
            if(dano < 0) {
            	System.out.println("Dano negativo, portanto será recupaerado 10 de vida");
            	dano = -10;
            }
            mago.pontosV -= dano;
            System.out.println("Mago sofreu dano! " + dano);
            System.out.println("Vida: " + mago.pontosV);
        } else {
        	mago.pontosA = mago.pontosA() * mago.inteligencia;
            guerreiro.pontosD = guerreiro.pontosD() * guerreiro.velocidade;
            dano = mago.pontosA - guerreiro.pontosD;
            if(dano < 0) {
            	System.out.println("Dano negativo, portanto será recupaerado 10 de vida");
            	dano = -10;
            }
            guerreiro.pontosV -= dano;
            System.out.println("Guerreiro sofreu dano! " + dano);
            System.out.println("Vida: " + guerreiro.pontosV);
        }
    }

    public static void verificarVencedor(Guerreiro G, Mago M, boolean resultado) {
        if (G.pontosV > M.pontosV || M.pontosV == 0) {
            System.out.println(G.nome + " Venceu!");
        } else if (M.pontosV > G.pontosV || G.pontosV == 0) {
            System.out.println(M.nome + " Venceu!");
        } else {
            System.out.println("Empate!");
        }
    }

    public static boolean iniciarBatalha(int tipoP1, Guerreiro guerreiro, Mago mago) {
    	 Scanner teclado = new Scanner(System.in);

    	    System.out.println("\nBATALHA INICIADA");

    	    char tipoJogador1 = 'a';
    	    char tipoJogador2 = 'a';
    	    boolean tipoPesonagem1 = true;
    	    boolean tipoPesonagem2 = true;
    	    
    	    if(tipoP1 == 1) {
    	    	   tipoJogador1 = 'G';
    	    	     tipoJogador2 = 'M';
    	    	      tipoPesonagem1 = true;
    	     	     tipoPesonagem2 = false;
    	     	    
    	    }else if(tipoP1 == 2) {
    	    	   tipoJogador1 = 'M';
    	    	     tipoJogador2 = 'G';
    	    	     tipoPesonagem1 = false;
    	     	     tipoPesonagem2 = true;
    	    }
    	  

    	    boolean resultado = false;

    	    
    	    for (int batalha = 0; batalha < 2; batalha++) {
    	        resultado = roll();

    	        for (int rodada = 0; rodada < 3; rodada++) {
    	        	 // Variáveis para indicar se cada jogador deseja aplicar um item
        	       

        	        System.out.println("Jogador 1, escolha se deseja aplicar um item (sim/nao):");
        	        String decisaoItemJogador1 = teclado.nextLine();
        	        while(!decisaoItemJogador1.equalsIgnoreCase("sim") && !decisaoItemJogador1.equalsIgnoreCase("nao")) {
        	        	System.out.println("Alternativa inválida");
        	        	System.out.println("Jogador 1, escolha se deseja aplicar um item (sim/nao):");
            	         decisaoItemJogador1 = teclado.nextLine();
        	        }
        	        if ((decisaoItemJogador1.equals ("sim"))) {
        	            gerenciarItem(tipoJogador1, guerreiro, mago);
        	        }

        	        System.out.println("Jogador 2, escolha se deseja aplicar um item (sim/nao):");
        	        String decisaoItemJogador2 = teclado.nextLine();
        	        while(!decisaoItemJogador2.equalsIgnoreCase("sim") && !decisaoItemJogador2.equalsIgnoreCase("nao")) {
        	        	System.out.println("Alternativa inválida");
        	        	System.out.println("Jogador 2, escolha se deseja aplicar um item (sim/nao):");
            	         decisaoItemJogador2 = teclado.nextLine();
        	        }
        	        if ((decisaoItemJogador2.equals ("sim"))) {
        	            gerenciarItem(tipoJogador2, guerreiro, mago);
        	        }

        	        // Se o jogador decidir aplicar um item, chamar o método para gerenciar o item
        	      

        	      
    	            if (resultado == true) {
    	                System.out.println("O jogador 1 começará a rodada " + (rodada + 1));
    	                AplicarDano(mago, guerreiro, tipoPesonagem1);

    	                if (mago.pontosV <= 0) {
    	                    System.out.println("Mago ficou sem vida. Guerreiro venceu!");
    	                    verificarVencedor(guerreiro, mago, resultado);
    	                    return false;
    	                } else if (guerreiro.pontosV <= 0) {
    	                    System.out.println("Guerreiro ficou sem vida. Mago venceu!");
    	                    verificarVencedor(guerreiro, mago, resultado);
    	                    return false;
    	                }
    	                resultado = false;

    	            } else {
    	                System.out.println("O jogador 2 começará a rodada " + (rodada + 1));
    	                AplicarDano(mago, guerreiro, tipoPesonagem2);

    	                if (mago.pontosV <= 0) {
    	                    System.out.println("Mago ficou sem vida. Guerreiro venceu!");
    	                    verificarVencedor(guerreiro, mago, resultado);
    	                    return false;
    	                } else if (guerreiro.pontosV <= 0) {
    	                    System.out.println("Guerreiro ficou sem vida. Mago venceu!");
    	                    verificarVencedor(guerreiro, mago, resultado);
    	                    return false;
    	                }
    	                resultado = true;
    	            }
    	        }
    	    }
    	    verificarVencedor(guerreiro, mago, resultado);
    	    return resultado;
    	}
}
