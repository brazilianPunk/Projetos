

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.Connection;

public class Conexao {
	public String url;
	public String porta;
	public String user;
	public String password;
	private String database;
	private Connection conexao;

	public Conexao(String host, String porta, String database, String user, String password) {
		this.url = "jdbc:mysql://" + host + ":" + porta + "/" + database;
		this.porta = porta;
		this.user = user;
		this.password = password;
		this.database = database;
		this.conexao = null;
		this.conectar();
	}

	public Conexao(final String database) {
		this.url = "jdbc:mysql:// " + "localhost:3306" + "Jogo";
		this.porta = "3306";
		this.user = "root@localhost";
		this.password = "mysql";
		this.database = "Jogo";
		this.conexao = null;
		this.conectar();
	}

	public void conectar() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.conexao = DriverManager.getConnection(this.url, this.user, this.password);
		} catch (Exception erro) {
			System.out.println("ERRO: " + erro.getMessage());
		}
	}

	public void desconectar() {
		try {
			this.conexao.close();
		} catch (Exception erro) {
			System.out.println("ERRO: " + erro.getMessage());
		}
	}

	public int executarAtualizacao(String sql) {
		int resultado = 0;
		try {
			Statement statement = this.conexao.createStatement();
			statement.executeUpdate(sql);
			resultado = 1;
		} catch (Exception erro) {
			System.out.println("ERRO: " + erro.getMessage());
		}
		return resultado;
	}

	public ResultSet executarSelect(String sql) {
		try {
			PreparedStatement ps = this.conexao.prepareStatement(sql);
			ResultSet resultado = ps.executeQuery();
			return resultado;
		} catch (Exception erro) {
			System.out.println("ERRO: " + erro.getMessage());
			return null;
		}
	}
}