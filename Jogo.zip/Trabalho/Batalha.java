import java.util.Scanner;
public class Batalha {

	public static void main(String[] args) {
		Boolean Guerreiro1 = false;
		Boolean Mago1= false;
		
		Boolean Guerreiro2 = false;
		Boolean Mago2 = false;
		
		Scanner teclado = new Scanner(System.in);
		Jogador j1 = new Jogador();
		Jogador j2 = new Jogador();
		
		Guerreiro G1 = new Guerreiro();
		Mago M1 = new Mago();
		
		Guerreiro G2 = new Guerreiro();
		Mago M2 = new Mago();
		
		ItensGuerreiro ItensG = new ItensGuerreiro();
		
		System.out.println("Digite o nome do jogador 1:");
		j1.nome = teclado.nextLine();
		
		System.out.println("Jogador 1: " +j1.nome);
		System.out.println("");
		
		
		System.out.println("Digite o nome do jogador 2:");
		j2.nome = teclado.nextLine();
		
		System.out.println("Jogador 2: " + j2.nome);
		System.out.println("");
		
		System.out.println( j1.nome +", Escolha um personagem");
		System.out.println(" 1: Guerreiro");
		System.out.println(" 2: Mago");
		
	    int tipoPersonagem1 =  teclado.nextInt();
	    
	    // Jogador 1 personagem
	    if(tipoPersonagem1 == 1) {
	    	 Guerreiro1 = true;
	    	
	    }else if(tipoPersonagem1 == 2) {
	    	 Mago1 = true;
	    }else {
	    	System.out.println("Opção inválida");
	    	
	    	while(tipoPersonagem1 != 1 || tipoPersonagem1 != 2) {
	    		System.out.println( j1.nome +", Escolha um personagem");
	    		System.out.println("1: Guerreiro");
	    		System.out.println("2: Mago");
	    		
	    		tipoPersonagem1 = teclado.nextInt();
	    		
	    		if(tipoPersonagem1 == 1 || tipoPersonagem1 == 2) {
	    			break;
	    		}
	    	}
	    	
	    	
	    }
	    
	    
	 
	    //Jogador 2 personagem
		System.out.println( j2.nome +", Escolha um personagem");
		System.out.println("1: Guerreiro");
		System.out.println("2: Mago");
		
		int tipoPersonagem2 =  teclado.nextInt();
		 
		   if(tipoPersonagem2 == 1) {
		    	 Guerreiro2 = true;
		    	
		    }else if(tipoPersonagem2 == 2) {
		    	 Mago2 = true;
		    }else {
		    	System.out.println("Opção inválida");
		    	
		    	while(tipoPersonagem2 != 1 || tipoPersonagem2 != 2) {
		    		System.out.println( j2.nome +", Escolha um personagem");
		    		System.out.println("1: Guerreiro");
		    		System.out.println("2: Mago");
		    		
		    		tipoPersonagem2 = teclado.nextInt();
		    		
		    		if(tipoPersonagem2 == 1 || tipoPersonagem2 == 2) {
		    			break;
		    		}
		    	}
		    }
		   
		   
		    System.out.println("Jogador 1:");
		    System.out.println("");
		    
		    System.out.println(j1.nome);
		    System.out.println("");
		    
		    
		    System.out.println("Personagem:");
		    if(Guerreiro1 == true) {
		    	System.out.println("Guerreiro");
		    	System.out.println("Vida: " + G1.pontosV);
		    	System.out.println("Ataque " + G1.pontosA);
		    	System.out.println("Defesa " + G1.pontosD);
		    	System.out.println("Força " + G1.forca);
		    	System.out.println("Velocidade " + G1.velocidade);
		    	System.out.println("");
		    	System.out.println("Itens disponíveis: ");
		    	 j1Items( true, false);
				    System.out.println("");
		    }else if(Mago1 == true) {
		    	System.out.println("Mago");
		    	System.out.println("Vida: " + M1.pontosV);
		    	System.out.println("Ataque " + M1.pontosA);
		    	System.out.println("Defesa " + M1.pontosD);
		    	System.out.println("Inteligencia " + M1.inteligencia);
		    	System.out.println("recuperação " + M1.recuperação);
		    	System.out.println("");
		    	System.out.println("Itens disponíveis: ");
		    	 j1Items( false, true);
				    System.out.println("");
		    }
		   
		   
		    
		    
		    System.out.println("Jogador 2:");
		    System.out.println("");
		    
		    System.out.println(j2.nome);
		    System.out.println("");
		    
		    
		    System.out.println("Personagem:");
		    if(Guerreiro2 == true) {
		    	System.out.println("Guerreiro");
		    	System.out.println("Vida: " + G2.pontosV);
		    	System.out.println("Ataque " + G2.pontosA);
		    	System.out.println("Defesa " + G2.pontosD);
		    	System.out.println("Força " + G2.forca);
		    	System.out.println("Velocidade " + G2.velocidade);
		    	System.out.println("");
		    	System.out.println("Itens disponíveis: ");
		    	j2Items( true, false);
		    
		    }else if(Mago2 == true) {
		    	System.out.println("Mago");
		    	System.out.println("Vida: " + M2.pontosV);
		    	System.out.println("Ataque " + M2.pontosA);
		    	System.out.println("Defesa " + M2.pontosD);
		    	System.out.println("Inteligencia " + M2.inteligencia);
		    	System.out.println("recuperação " + M2.recuperação);
		    	System.out.println("");
		    	System.out.println("Itens disponíveis: ");
		    	j2Items( false, true);
		    }
		    System.out.println("");
		    
		    
		
		    
		 ///////////   //INICIAR BATALHA////////////////
		    
	}
	
	
	
	
	public static void j1Items(Boolean Guerreiro1,Boolean Mago1) {
		ItensGuerreiro ItensG = new ItensGuerreiro();
		ItensMago ItensM = new ItensMago();
		
		if(Guerreiro1 == true) {
			//Ataque
		Double item1 = ItensG.Porrete;
		System.out.println("Porrete");
		Double item2 = ItensG.Escudo;
		System.out.println("Escudo");
		Double item3 = ItensG.Espada;
		System.out.println("Espada");
		Double item4 = ItensG.Lança;
		System.out.println("Lança");
		Double item5 = ItensG.Machado;
		System.out.println("Machado");
		
		//Defesa
		Double item6 = ItensG.Armadura;
		System.out.println("Armadura");
		Double item7 = ItensG.Capa;
		System.out.println("Capa");
		Double item8 = ItensG.Cinta;
		System.out.println("Cinta");
		Double item9 = ItensG.Capacete;
		System.out.println("Capacete");
		Double item10 = ItensG.Bracelete;
		System.out.println("Bracelete");
		
		}else if(Mago1 == true){
			
			//Ataque
			Double item1 = ItensM.CajadodoTrovão;
			System.out.println("CajadodoTrovão");
			Double item2 = ItensM.LançaDeÁgua;
			System.out.println("LançaDeÁgua");
			Double item3 = ItensM.AdagaDeGelo;
			System.out.println("AdagaDeGelo");
			Double item4 = ItensM.EspadaDeLuz;
			System.out.println("EspadaDeLuz");
			Double item5 = ItensM.CetrodaTerra;
			System.out.println("CetrodaTerra");
			
			//Defesa
			Double item6 = ItensM.Capa;
			System.out.println("Capa");
			Double item7 = ItensM.Tunica;
			System.out.println("Tunica");
			Double item8 = ItensM.AnelMagico;
			System.out.println("AnelMagico");
			Double item9 = ItensM.CampoProtetivo;
			System.out.println("CampoProtetivo");
			Double item10 = ItensM.CorvoDeOdin;
			System.out.println("CorvoDeOdin");
		}
		
	}

	public static void j2Items(Boolean Guerreiro2,Boolean Mago2) {
		ItensGuerreiro ItensG = new ItensGuerreiro();
		ItensMago ItensM = new ItensMago();
		
		if(Guerreiro2 == true) {
			//Ataque
		Double item1 = ItensG.Porrete;
		System.out.println("Porrete");
		Double item2 = ItensG.Escudo;
		System.out.println("Escudo");
		Double item3 = ItensG.Espada;
		System.out.println("Espada");
		Double item4 = ItensG.Lança;
		System.out.println("Lança");
		Double item5 = ItensG.Machado;
		System.out.println("Machado");
		
		//Defesa
		Double item6 = ItensG.Armadura;
		System.out.println("Armadura");
		Double item7 = ItensG.Capa;
		System.out.println("Capa");
		Double item8 = ItensG.Cinta;
		System.out.println("Cinta");
		Double item9 = ItensG.Capacete;
		System.out.println("Capacete");
		Double item10 = ItensG.Bracelete;
		System.out.println("Bracelete");
		
		}else if(Mago2 == true){
			
			//Ataque
			Double item1 = ItensM.CajadodoTrovão;
			System.out.println("CajadodoTrovão");
			Double item2 = ItensM.LançaDeÁgua;
			System.out.println("LançaDeÁgua");
			Double item3 = ItensM.AdagaDeGelo;
			System.out.println("AdagaDeGelo");
			Double item4 = ItensM.EspadaDeLuz;
			System.out.println("EspadaDeLuz");
			Double item5 = ItensM.CetrodaTerra;
			System.out.println("CetrodaTerra");
			
			//Defesa
			Double item6 = ItensM.Capa;
			System.out.println("Capa");
			Double item7 = ItensM.Tunica;
			System.out.println("Tunica");
			Double item8 = ItensM.AnelMagico;
			System.out.println("AnelMagico");
			Double item9 = ItensM.CampoProtetivo;
			System.out.println("CampoProtetivo");
			Double item10 = ItensM.CorvoDeOdin;
			System.out.println("CorvoDeOdin");
		}
		
	}
}
